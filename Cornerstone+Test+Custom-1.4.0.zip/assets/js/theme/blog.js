import PageManager from '../page-manager';

export default class Blog extends PageManager {}

